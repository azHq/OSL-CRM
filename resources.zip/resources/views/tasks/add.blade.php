<div class="modal center fade" id="add_task" tabindex="-1" role="dialog" aria-modal="true" style="margin-top: 2em;">
	<div class="modal-dialog lkb-modal-dialog" role="document">
		<button type="button" class="btn-close md-close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
		<div class="modal-content">

			<div class="modal-header">
				<h4 class="modal-title text-center">Assign Task</h4>
				<button type="button" class="btn-close xs-close" data-bs-dismiss="modal"></button>
			</div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">
						<form action="{{ route('tasks.store') }}" id="task-add" method="POST">
							@csrf
							<div class="row">
								<div class="col">
									<div class="form-group row">
										<div class="col-sm-12">
											<label class="col-form-label">Assign Person</label>
											<select class="form-control form-select" name="assignee_id" id="task-add-counsellor-id">

											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="form-group row">
										<div class="col-md-12"><label class="col-form-label">Task Name<span class="text-danger">*</span></label></div>
										<div class="col-md-12">
											<input id="task-add-name" class="form-control" type="text" name="name" required>
										</div>
									</div>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-12">
									<label class="col-form-label">Task Details <span class="text-danger">*</span></label>
									<textarea type="text" id="task-add-details" class="form-control" name="details" placeholder="About Task" required></textarea>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="form-group row">
										<div class="col-sm-12">
											<label class="col-form-label">Start Date and Time <span class="text-danger">*</span></label>
											<input type='text' class="form-control" id='task-add-start-date' name="start_date" required>
											<!-- <input type="datetime-local" id="task-add-start-date" class="form-control" name="start_date" required> -->

										</div>
									</div>
									<div class="col">
										<div class="form-group row">
											<div class="col-sm-12">
												<label class="col-form-label">End Date and Time<span class="text-danger">*</span></label>
												<input type='text' class="form-control" id='task-add-end-date' name="end_date" required>

												<!-- <input type="datetime-local" id="task-add-end-date" class="form-control" name="end_date" required> -->
											</div>
										</div>
									</div>
									<input type="hidden" id="task-type" class="form-control" name="task_type" required>
								</div>
								<div class="text-center py-3">
									<button type="submit" class="border-0 btn btn-primary btn-gradient-primary btn-rounded">Save</button>&nbsp;&nbsp;
									<button type="button" class="btn btn-secondary btn-rounded" data-bs-dismiss="modal">Cancel</button>
								</div>

							</div>
						</form>
					</div>
				</div>

			</div>

		</div><!-- modal-content -->
	</div>
	<!-- modal-dialog -->
</div>

@if(Route::current()->getName() == 'tasks.index')
<script>
	$('#task-type').val('Scheduled');
</script>
@endif
@if(Route::current()->getName() == 'dashboard')
<script>
	$('#task-type').val('Normal');
</script>
@endif

<script src="{{ URL::asset('/assets/js/datetimepicker.min.js')}}"></script>
<script src="{{ URL::asset('/assets/js/moment.min.js')}}"></script>
<!-- <script src="{{ URL::asset('/assets/js/bootstrap.min.js')}}"></script> -->
<script type="text/javascript">
	$(function() {
		$('#task-add-start-date').datetimepicker({
			sideBySide : true,
			format:'YYYY-MM-DD hh:mm:ss'
		});
		$('#task-add-end-date').datetimepicker({
			sideBySide : true,
			format:'YYYY-MM-DD hh:mm:ss'
		});
	});
</script>
@if (Auth::user()->hasRole('super-admin') || Auth::user()->hasRole('main-super-admin'))
<script>
	$(document).ready(function() {
		$.ajax({
			type: 'GET',
			url: "{{ route('leads.create') }}",
			success: function(data) {
				let options = '';
				options = '<option value="" selected>Filter Person</option>';
				options += '<option value="Unassigned">Unassigned</option>';
				if (data.users) {
					data.users.forEach(function(user) {
						options += '<option value="' + user.id + '">' + user.name + '(Counsellor)</option>';
					});
				}
				if (data.cros) {
					data.cros.forEach(function(user) {
						options += '<option value="' + user.id + '">' + user.name + '(CRO)</option>';
					});
				}
				$('#task-add-counsellor-id').html(options);
			}
		});
	});
</script>
@else
<script>
	$(document).ready(function() {
		$.ajax({
			type: 'GET',
			url: "{{ route('leads.create') }}",
			success: function(data) {
				var options = '';
				data.me_and_sa.forEach(function(user) {
					options += '<option value="' + user.id + '">' + user.name + '</option>';
				});
				$('#task-add-counsellor-id').html(options);
			}
		});
	});
</script>
@endif